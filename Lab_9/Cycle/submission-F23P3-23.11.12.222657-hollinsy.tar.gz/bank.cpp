// Project identifier: 292F24D17A4455C1B5133EDD8C7CEAA0C9570A98
// Created by fs200 on 2023/11/5.

#include <iostream>
using std::cout, std::cin, std::cerr, std::endl, std::getline;
#include <string>
using std::string, std::stringstream;
#include <cstdint>
#include <queue>
using std::priority_queue;
#include <deque>
using std::deque;
#include <algorithm>
using std::lower_bound, std::upper_bound;
#include <fstream>
using std::ifstream;
#include "Structs.h"
#include "commandLine.h"

inline void printFormattedTime(uint64_t);

int main(int argc, char* argv[]) {
    std::ios_base::sync_with_stdio(false);  // speed up I/O
    Options options;
    getMode(argc, argv, options);
    if (!options.haveFile) {
        cerr << "No file!" << endl;
        exit(1);
    }
    Bank bank;
    ifstream regFile;
    regFile.open(options.fileName);
    string tmpStr;

    while (regFile) {
        regFile >> tmpStr;
        User u(tmpStr);
        bank.users.insert({u.ID, u});
    } // read users
    regFile.close();

    /* -------------------- read commands -------------------- */
    tmpStr.clear();
    while(tmpStr != "$$$") {
        getline(cin, tmpStr);
        stringstream ss(tmpStr);
        if (tmpStr[0] == 'l') {
            /* login and check validity */
            string tempIP, user;
            uint32_t tempPIN;
            ss >> tempIP >> user >> tempPIN >> tempIP;
//            cout << "try login: " << tempIP << " " << user  << " " << tempPIN << "correct PIN: " << endl;
            bool loginSuccess = bank.login(tempIP, user, tempPIN);
            if (options.verbose) {
                if (loginSuccess) cout << "User " << user << " logged in.\n";
                else cout << "Failed to log in " << user << ".\n";
            }
        } else if (tmpStr[0] == 'o') {
            /* logout */
            string tempID, tempIP;
            ss >> tempID >> tempID >> tempIP;
            bool logoutSuccess = bank.logout(tempID, tempIP);
//            cout << "logout: " << tempID << " " << tempIP << endl;
            if (options.verbose) {
                if (!logoutSuccess)
                    cout << "Failed to log out " << tempID << ".\n";
                else
                    cout << "User " << tempID << " logged out.\n";
            }
        } else if (tmpStr[0] == 'p') {
            /* place and check validity */
            Transaction t(tmpStr);
            bank.checkTransaction(t, options.verbose);
        } else if (tmpStr[0] == '$') { break; }
        else if (tmpStr[0] == '#') {/* comment */}
    }

    /* this time should be larger than any 12-digit date */
    bank.executeTransaction(100000000000000ULL, options.verbose);
    if (!bank.transactions.empty()) cerr << "why is it not empty?" << endl;

    std::sort(bank.TML.begin(), bank.TML.end(), CompareTransactionExe());

    /* -------------------- query -------------------- */
    while(getline(cin, tmpStr)) {
        if (cin.fail()) break;
        stringstream ss(tmpStr.substr(2));  // ss contains everything but the first two chars
        switch (tmpStr[0]) {
            case 'l': {
                uint64_t start, end;
                string str1, str2;
                ss >> str1 >> str2;
                start = transactionTime(str1);
                end = transactionTime(str2);
                int transCnt = 0;
                for (auto & t: bank.TML) {
                    if (t.executed && (t.exeDate >= start) && (t.exeDate < end)) {
                        cout << t.ID << ": " << t.sender << " sent " <<
                             t.amount;
                        if (t.amount == 1) cout << " dollar ";
                        else cout << " dollars ";
                        cout << "to " << t.recipient << " at " << t.exeDate << ".\n";
                        ++transCnt;
                    }
                }
                string be = (transCnt == 1) ? "was" : "were";
                string transactions = (transCnt == 1) ? " transaction " : " transactions ";
                cout << "There " << be << " " << transCnt << transactions << "that "<< be << " placed between time "
                        << start << " to " << end << ".\n";
                break;
            }
            case 'r': {
                uint64_t start, end;
                uint32_t revenue = 0;
                string str1, str2;
                ss >> str1 >> str2;
                start = transactionTime(str1);
                end = transactionTime(str2);
                for (auto &t: bank.TML) {
                    if (t.executed && (t.exeDate >= start) && (t.exeDate < end)) {
                        revenue += t.totalFee;
                    }
                    if (t.exeDate >= end) break;
                }
                cout << "281Bank has collected " << revenue << " dollars in fees over";
                printFormattedTime(end - start);
                cout << ".\n";
                break;
            }
            case 'h': {
                string user;
                ss >> user;
                if (bank.users.find(user) == bank.users.end()) {
                    cout << "User " << user << " does not exist.\n";
                    break;
                }
                deque<Transaction*> In, Out;    // use pushback to add data
                int inCnt = 0, outCnt = 0;
                for (auto &t: bank.TML) {
                    if (t.executed) {
                        if (t.sender == user) {
                            ++outCnt;
                            Out.push_back(&t);
                            if (Out.size() > 10) Out.pop_front();
                        }
                        if (t.recipient == user) {
                            ++inCnt;
                            In.push_back(&t);
                            if (In.size() > 10) In.pop_front();
                        }
                    }
                }
                cout << "Customer " << user << " account summary:\n" << "Balance: $" << bank.users[user].balance
                        << "\nTotal # of transactions: " << inCnt + outCnt << "\n";

                cout << "Incoming " << inCnt << ":\n";
                for (auto &t: In) {
                    cout << t->ID << ": " << t->sender << " sent " << t->amount;
                    if (t->amount == 1) cout << " dollar ";
                    else cout << " dollars ";
                    cout << "to " << t->recipient << " at " << t->exeDate << ".\n";
                }

                cout << "Outgoing " << outCnt << ":\n";
                for (auto &t: Out) {
                    cout << t->ID << ": " << t->sender << " sent " << t->amount;
                    if (t->amount == 1) cout << " dollar ";
                    else cout << " dollars ";
                    cout << "to " << t->recipient << " at " << t->exeDate << ".\n";
                }
                break;
            }
            case 's': {
                uint64_t time = transactionTime(ss.str());
                time = (time / 1000000ULL) * 1000000ULL;
                cout << "Summary of [" << time << ", " << time + 1000000ULL << "):\n";
                uint32_t revenue = 0;
                int transNum = 0;
                for (auto &t: bank.TML) {
                    if (t.executed && (t.exeDate >= time) && (t.exeDate < time + 1000000ULL)) {
                        revenue += t.totalFee;
                        cout << t.ID << ": " << t.sender << " sent " << t.amount;
                        if (t.amount == 1) cout << " dollar ";
                        else cout << " dollars ";
                        cout << "to " << t.recipient << " at " << t.exeDate << ".\n";
                        ++transNum;
                    }
                    if (t.exeDate >= time + 1000000ULL) break;
                }
                cout << "There ";
                if (transNum == 1) cout << "was";
                else cout << "were";
                cout << " a total of " << transNum;
                if (transNum == 1) cout << " transaction";
                else cout << " transactions";
                cout << ", 281Bank has collected " << revenue << " dollars in fees.\n";
                break;
            }
            default:
                break;
        }
    }
//    bank.printAll();
    return 0;
}

inline void printFormattedTime(uint64_t time) {
    uint64_t seconds, minutes, hours, days, months, years;
    years = time / 10000000000ULL;
    time -= years * 10000000000ULL;
    months = time / 100000000ULL;
    time -= months * 100000000ULL;
    days = time / 1000000ULL;
    time -= days * 1000000ULL;
    hours = time / 10000ULL;
    time -= hours * 10000ULL;
    minutes = time / 100ULL;
    time -= minutes * 100ULL;
    seconds = time;
    if (years == 1ULL)
        cout << " " << years << " year";
    else if (years != 0ULL)
        cout << " " << years << " years";

    if (months == 1ULL)
        cout << " " << months << " month";
    else if (months != 0ULL)
        cout << " " << months << " months";

    if (days == 1ULL)
        cout << " " << days << " day";
    else if (days != 0ULL)
        cout << " " << days << " days";

    if (hours == 1ULL)
        cout << " " << hours << " hour";
    else if (hours!=0ULL)
        cout << " " << hours << " hours";

    if (minutes == 1ULL)
        cout << " " << minutes << " minute";
    else if (minutes!=0ULL)
        cout << " " << minutes << " minutes";

    if (seconds == 1ULL)
        cout << " " << seconds << " second";
    else if (seconds!=0ULL)
        cout << " " << seconds << " seconds";
}

