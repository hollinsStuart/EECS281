// Project identifier: 292F24D17A4455C1B5133EDD8C7CEAA0C9570A98
// Created by fs200 on 2023/11/5.

#ifndef P3_PY_STRUCTS_H
#define P3_PY_STRUCTS_H

#include <iostream>
using std::cout, std::cin, std::cerr, std::endl, std::getline;
#include <string>
using std::string;
#include <sstream>
using std::stringstream;
#include <cstdint>
#include <deque>
using std::deque;
#include <vector>
using std::vector;
#include <queue>
using std::priority_queue;
#include <unordered_map>
using std::unordered_map;
#include <algorithm>
using std::find;

/* convert precise time to int */
inline uint64_t transactionTime(const string& s) {
    stringstream ss(s);
    uint64_t ans = 0, temp;
    char c;
    ss >> temp >> c;
    ans += temp;
    ans *= 100ULL;
    ss >> temp >> c;
    ans += temp;
    ans *= 100ULL;
    ss >> temp >> c;
    ans += temp;
    ans *= 100ULL;
    ss >> temp >> c;
    ans += temp;
    ans *= 100ULL;
    ss >> temp >> c;
    ans += temp;
    ans *= 100ULL;
    ss >> temp;
    ans += temp;
    return ans;
}

/* convert date to int */
inline uint64_t transactionDate(const string& s) {
    stringstream ss(s);
    uint64_t ans = 0, temp;
    ss >> temp;
    ans += temp;
    ans *= 1000000ULL;
    return ans;
}


class User {
public:
    User() = default;
    ~User() = default;

    explicit User(const string &str) {
        regTime = transactionTime(str.substr(0, 17));
//        cout << "time from " << str.substr(0, 16) << endl;
        string rest = str.substr(18);
        size_t pos = rest.find('|');
        ID = rest.substr(0, pos);
        stringstream ss(rest.substr(pos+1));
        char c;
        ss >> PIN >> c >> balance;
    }

    void print() const;

    uint64_t regTime{};
    string ID;
    uint32_t PIN{};
    uint32_t balance{};
    unordered_map<string, char> validIP;
};


class Transaction {
public:
    Transaction() = default;
    ~Transaction() = default;

    /* str is the line with place */
    explicit Transaction(const string &str) {
        stringstream ss(str);
        string ts, et;
        char c;
        ss >> et >> ts >> IP >> sender >> recipient >> amount >> et >> c;
        /* ts: timeStamp, et: exe_time, c: o/s */
        timeStamp = transactionTime(ts);
        exeDate = transactionTime(et);
        if (c == 's') share = true;
        else share = false;
    }

    Transaction(const Transaction& t) = default;

    void print() const;

    uint64_t timeStamp{};
    string IP{};
    string sender;
    string recipient;
    uint32_t amount{};
    uint64_t exeDate{};
    uint32_t totalFee{0};
    int ID{-1};
    bool share{};     // true: share
    bool executed{false};
};


class CompareTransactionExe {
public:
    CompareTransactionExe() = default;
    ~CompareTransactionExe() = default;

    bool operator()(const Transaction& t1, const Transaction& t2) const {
        if (t1.exeDate == t2.exeDate) return t1.ID < t2.ID;
        return t1.exeDate < t2.exeDate;
    }

    bool operator()(const Transaction* t1, const Transaction* t2) const {
        if (t1->exeDate == t2->exeDate) return t1->ID < t2->ID;
        return t1->exeDate < t2->exeDate;
    }
};

class CompareTransactionExePQ {
public:
    CompareTransactionExePQ() = default;
    ~CompareTransactionExePQ() = default;

    bool operator()(const Transaction& t1, const Transaction& t2) const {
        if (t1.exeDate == t2.exeDate) return t1.ID > t2.ID;
        return t1.exeDate > t2.exeDate;
    }

    bool operator()(const Transaction* t1, const Transaction* t2) const {
        if (t1->exeDate == t2->exeDate) return t1->ID > t2->ID;
        return t1->exeDate > t2->exeDate;
    }
};

class CompareReverseTime {
public:
    CompareReverseTime() = default;
    ~CompareReverseTime() = default;

    bool operator()(const Transaction& t1, const Transaction& t2) const {
        if (t1.exeDate == t2.exeDate) return t1.ID < t2.ID;
        return t1.exeDate < t2.exeDate;
    }

    bool operator()(const Transaction* t1, const Transaction* t2) const {
        if (t1->exeDate == t2->exeDate) return t1->ID < t2->ID;
        return t1->exeDate < t2->exeDate;
    }
};


class Bank {
public:
    Bank() = default;
    ~Bank() = default;

    void printUsers();
    void printTransactions();
    void printAll();

    bool login(const string& ip, const string& id, uint32_t pin) {
        if (users.find(id) == users.end()) return false;    // no such user
        if (pin == users[id].PIN) {
            // add ip to the list
            users[id].validIP.insert({ip,ip[0]});
        } else {
            return false;
        }
        return true;
    }

    bool logout(const string& id, const string& ip) {
        if (users.find(id) == users.end()) return false;    // no such user

        if (users[id].validIP.find(ip) != users[id].validIP.end()) {
            // found
            users[id].validIP.erase(ip);
            return true;
        } else {
            // no such IP
            return false;
        }
    }

    bool checkTransaction(Transaction& t, bool verbose) {
//        cout << "checking trans:\n";
//        t.print();
        if (t.timeStamp + 3000000ULL < t.exeDate) {
            if (verbose) {
                cout << "Select a time less than three days in the future.\n";
                return false;
            }
        }
        auto senderIT = this->users.find(t.sender);
        auto recipientIT = this->users.find(t.recipient);
        if (senderIT == this->users.end()) {
            if (verbose) cout << "Sender " << t.sender << " does not exist.\n";
            return false;
        }
        if (recipientIT == this->users.end()) {
            if (verbose) cout << "Recipient " << t.recipient << " does not exist.\n";
            return false;
        }
        if ((users[t.sender].regTime > t.exeDate) || (users[t.recipient].regTime > t.exeDate)) {
            if (verbose) cout << "At the time of execution, sender and/or recipient have not registered.\n";
            return false;
        }
        if (users[t.sender].validIP.empty()) {
            if (verbose) cout << "Sender " << t.sender << " is not logged in.\n";
            return false;
        }
        if (users[t.sender].validIP.find(t.IP) == users[t.sender].validIP.end()) {
            if (verbose) cout << "Fraudulent transaction detected, aborting request.\n";
            return false;
        }
        t.ID = this->transactionID;
        ++this->transactionID;
        executeTransaction(t.timeStamp, verbose);
        this->TML.push_back(t);
        this->transactions.push(&this->TML.back());
        if (verbose) {
            cout << "Transaction placed at " << t.timeStamp << ": $" << t.amount << " from "
                 << t.sender << " to " << t.recipient << " at " << t.exeDate << ".\n";
        }
        return true;
    }

    /* Execute transactions until time. Exe all, set time to 18446744073709551615 */
    inline void executeTransaction(uint64_t time, bool verbose) {
        while (!this->transactions.empty() && this->transactions.top()->exeDate < time) {
            Transaction* t = this->transactions.top();
            this->transactions.pop();
            uint32_t transFee = t->amount / 100, senderFee{0}, recipientFee{0};
            if (transFee < 10) transFee = 10;
            if (transFee > 450) transFee = 450;
            if (this->users[t->sender].regTime + 50000000000ULL < t->exeDate) {
                transFee = (transFee * 3) / 4;
            }
            t->totalFee = transFee;
            if (t->share) {
                senderFee = transFee / 2;
                if (transFee % 2 == 1) ++senderFee;
                recipientFee = transFee - senderFee;
            } else {
                senderFee = transFee;
            }
            if (this->users[t->sender].balance < senderFee + t->amount
                    || this->users[t->recipient].balance < recipientFee) {
                if (verbose) cout << "Insufficient funds to process transaction " << t->ID << ".\n";
                return;
            } else {
                /* execute successfully */
                this->users[t->sender].balance -= senderFee + t->amount;
                this->users[t->recipient].balance += (t->amount - recipientFee);
                t->executed = true;
                if (verbose)
                    cout << "Transaction executed at " << t->exeDate << ": $" << t->amount << " from "
                        << t->sender << " to " << t->recipient << ".\n";
            }
        }
    }

    unordered_map<string, User, std::hash<string>> users;
    deque<Transaction> TML; // transaction primary list
    priority_queue<Transaction*, vector<Transaction*>, CompareTransactionExePQ> transactions;
//    unordered_map<string, vector<string>> userIPList;
    int transactionID{0};

};
#endif //P3_PY_STRUCTS_H
